#!/usr/bin/perl -w
# @(#)unfrag.pl (c) 1997 Graham THE Ollis
#===============================================================================
# unfrag.pl - unfrag fragments generated from the unix (perl) or dos (16bit)
#		versions of frag.
#
# History:
# Date       Author     Comment
# ----       ------     -------
# 07 feb 97  G. Ollis	created script
#===============================================================================
# options:
# -h		help
# -p		pause between fragments
# -ow		overwrite by default
# -no_ow	don't overwrite
#===============================================================================

require 5;
use integer;
use English;

$PAUSE = 0;
$OW = 0;
$index = 0;

while(defined($ARGV[0]) and ($ARGV[0] =~ m/^-/)) {
  $option = shift(@ARGV);

  if($option =~ m/^-h(|elp)$/i) {
    &printhelp;
    exit 0;

  } elsif($option =~ m/-ow$/i) {
    $OW = 1;
  } elsif($option =~ m/-no_ow$/i) {
    $OW = 0;

  } elsif($option =~ m/^-p(|ause)$/i) {
    $PAUSE = 1;

  } else {
    print STDERR "unknown option: $option\n";
    exit 2;
  }
}

if(($#ARGV != 0) and ($#ARGV != 1)) {
  print "usage: $0 [options] frag [file]\n";
  exit 2;
}

#===============================================================================
# lets get to work now...
#===============================================================================

$infile = $ARGV[0];
$outfile = $ARGV[1] if defined $ARGV[1];

#===============================================================================
# first step is to figure out which of the very many fragment types we have
# to deal with here.  *sigh* life can be difficult sometimes.
#===============================================================================

my($tmp) = $infile . '1.frg';

if(-e "$infile.f01") {
  print "new fragment detected\n";
  $fragtype = 'new';
} elsif(-e $tmp) {
  print "old fragment detected\n";
  $fragtype = 'old';
} elsif(-e "$infile.0.frag") {
  print "long file name fragment detected\n";
  $fragtype = 'long';
} else {
  print "$0: could not locate fragment you requested\n";
  exit 1;
}

$outfile = &outfilename;

if(($OW == 0) and (-e $outfile)) {
  print "$0: error, file $outfile exists\n";
  exit 2;
}

#===============================================================================
# finally open up the files and inirate away!
#===============================================================================

open(OUT, ">$outfile") || die "unable to open $outfile $!";

my($buffer) = '';

$frag = &fragmentname;
while(-e $frag) {
  open(IN, $frag) || die "unable to open fragment $frag $!";

  &header;

  while(read(IN, $buffer, 16384)) {
    print OUT $buffer; 
  }
  close(IN);
  
  $frag = &fragmentname;
}

&laststuff;

#===============================================================================
# &laststuff;
#===============================================================================

sub laststuff {
  return unless $fragtype eq 'new';
  
  print "warning: output file is short!\n" 
     if($last{'total_size'} != tell OUT);  

  #=============================================================================
  # the latest (unix) version stores attribute and ownership values.
  # set these where possible.
  #=============================================================================

  if($last{'version'} >= 2) {
    if($REAL_USER_ID == 0) {
      chown $last{'unx_uid'}, $last{'unx_gid'}, $outfile;
    }
    chmod $last{'unx_mode'}, $outfile;
  }
}

#===============================================================================
# &header;
#===============================================================================

sub header {
  return unless $fragtype eq 'new';
  my($buffer) = '';

  read IN, $buffer, 60;

  my(%c) = ();		#current file
  (#version 2.x
   $c{'ID'}, $c{'version'}, $c{'index'}, $c{'time'}, $c{'dest_offset'},
   $c{'total_size'}, $c{'dos_fn_len'}, $c{'dos_fn'}, $c{'head_size'},
   $c{'frag_mode'}, $c{'frag_size'},

   #version 3.x
   $c{'unx_mode'}, $c{'unx_uid'}, $c{'unx_gid'}, 
   $c{'unx_fn_off'}, $c{'unx_fn_size'})

   = unpack	'a3CCVVVCa12vCV'  .	# version 2.x
		'vVVVV', $buffer;	# version 3.x

  if($c{'ID'} ne 'FRG') {
    print STDERR "$0: error, $frag is not in new fragment format.\n";
    exit 1;
  }

  print "warning: index $c{'index'} seems to be incorrect for $frag\n"
    if($c{'index'} != $index);

  if(defined %last) {

    #===========================================================================
    # fragment version 2.x
    #===========================================================================

    for('version', 'time', 'total_size', 
        'head_size', 'frag_mode', 'frag_size') {
      print "warning: $_ in $frag does not match initial fragment\n"
         if($last{$_} != $c{$_});
    }

    #===========================================================================
    # fragment version 3.x
    #===========================================================================

    if($last{'version'} >= 2) {
      for('unx_mode', 'unx_uid', 'unx_gid', 'unx_fn_off', 'unx_fn_size') {
        print "warning: $_ in $frag does not match initial fragment\n"
           if($last{$_} != $c{$_});
      }
    }
  }

  seek IN, $c{'head_size'}+1, 0;

  my($offset) = $c{'dest_offset'} + 1;
  if($offset != tell(OUT)) {
    print "warning: $frag is noncontiguous\n"
      if(($offset-1) != tell(OUT));
    print "should:", $offset-1, " is:", tell(OUT), "\n";
    seek OUT, $offset, 0;
  }

#  print '=' x 70, "\n";
#  print "$frag\n";
#  foreach $key (keys %c) {
#    print "$key = $c{$key}\n";
#  }

  %last = %c unless defined %last;

}

#===============================================================================
# &fragmentname;
#===============================================================================

sub fragmentname {
  my($name);

  if($fragtype eq 'long') {
    $name = "$infile.$index.frag";
    $index++;

  } elsif($fragtype eq 'new') {
    $index++;
    $name = "$infile.f";
    $name .= '0' if($index < 10);
    $name .= $index;

  } else {
    $index++;
    $name = "$infile$index.frg";
  }

  $name;
}

#===============================================================================
# &outfilename;
#===============================================================================

sub outfilename {
  return $outfile if defined $outfile;

  if($fragtype eq 'new') {
    open(FP, "$infile.f01") || die "could not open initial fragment $!";

    my($data) = '';
    read FP, $data, 4;
    my($id, $version) = unpack 'a3C', $data;

    #===========================================================================
    # fragment 3.x (32bit unix long file names)
    #===========================================================================

    if($version >= 2) {
      if($version > 2) {
        print "this seems to be a post 3.x fragment.  should be ok though.\n";
      } else {
        print "probably a 3.x fragment.  i should have no trouble with this.\n";
      }
      seek FP, 47, 0;
      read FP, $data, 8;
      my($fn_offset, $fn_length) = unpack 'VV', $data;
      seek FP, $fn_offset, 0;
      read FP, $data, $fn_length;
      return $data;
    }

    #===========================================================================
    # fragment 2.x (16bit DOS SUCKS)
    #===========================================================================

    seek FP, 18, 0;
    read FP, $data, 12;
    $data = unpack 'a12', $data;
    return $data;

  }

  $infile;
}

#===============================================================================
# &printhelp;
#===============================================================================

sub printhelp {
  print " GUTIL program unfrag by Graham THE Ollis.\n";
  print " version 3.00 (perl)\n";
  print "\n";
  print "  unfrag [options] source_file [destination file]\n";
  print "\n";
  print "unfrag defrags a collection of frags made by frag.\n";
  print "\n";
  print "options available:\n";
  print "-p            pause between fragments\n";
  print "-ow           overwrite any previously existing file\n";
  print "-no_ow        do not overwrite any previous existing file\n";
}

