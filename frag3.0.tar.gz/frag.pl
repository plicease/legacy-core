#!/usr/bin/perl -w
# @(#)frag.pl (c) 1997 Graham THE Ollis
#===============================================================================
# frag.pl - read and write files of the old and new FRAG format.
#           a really useful frag utility which originated on 16bit DOS.
#
# History:
# Date       Author     Comment
# ----       ------     -------
# 07 feb 97  G. Ollis	created script
#===============================================================================
# options:
# -Pause	pause between each file (to swap disks)
# -S:size(t)	size in segments
#		t is:
#		  s - segments
#		  b - bytes
#		  k - kilobytes (-k: depreciated)
#		  m - megabytes
# -Old		old mode (no header data)
# -New		new mode (header data)
# -Long		unix mode (.num.frag files)
# -OW		over write existing files
# -NO_OW	prompt before writing over eisting files (default)
#
# -ST		stamp the disk (where the 1 file is) for easy unfraging
# -C fn		Continue - fn is the last fragment or partial fragment
# -SC		scan the destination disk to completely fill it
#===============================================================================
# NOTES:
#
#  * size does not include header if you are using the "new" mode
#===============================================================================

require 5;
use integer;

%pref = (	# prefrences

  'pause'	=> 0,
  'size'	=> 1441748,	# old default from 16bit 0xfffe * 22
  'mode'	=> 'new',
  'ow'		=> 0,

  'null'	=> 'null'
);

$index = 0;
$0 =~ s!^.*/!!g;

#===============================================================================
# parse command line options
#===============================================================================

while(defined($ARGV[0]) and ($ARGV[0] =~ m/^-/)) {
  $option = shift(@ARGV);

  # -pause
  if($option =~ m/^-p(|ause)$/i) {
    $pref{'pause'} = 1;

  # overwrite
  } elsif($option =~ m/^-ow/i) {
    $pref{'ow'} = 1;
  } elsif($option =~ m/^-no_ow/i) {
    $pref{'ow'} = 0;

  # mode (-old -new -long)
  } elsif($option =~ m/^-n(|ew)/i) {
    $pref{'mode'} = 'new';
  } elsif($option =~ m/^-o(|ld)/i) {
    $pref{'mode'} = 'old';
  } elsif($option =~ m/^-l(|ong)/i) {
    $pref{'mode'} = 'long';

  # -k: size in kilobytes
  } elsif($option =~ m/^-k:(\d+)$/i) {
    $pref{'size'} = $1;

  # -s:size(t) set size in segments, bytes, kilo and megabytes
  } elsif($option =~ m/^-s(|ize):(\d+)(|s|b|k|m)$/i) {
    if($3 eq 'b') {
      $pref{'size'} = $2;
    } elsif($3 eq 'k') {
      $pref{'size'} = $2 * 1024;
    }elsif($3 eq 'm') {
      $pref{'size'} = $2 * 1024 * 1024;
    } else {
      $pref{'size'} =  $2 * oct('0xfffe');
    }

  } elsif($option =~ m/^-h(|elp)/i) {
    &printhelp;
    exit 0;

  # unknown option
  } else {
    print STDERR "unknown option $option\n";
    exit 2;
  }

}

if(($#ARGV != 0) and ($#ARGV != 1)) {
  print "usage: $0 [options] file [frag_name]\n";
  exit 2;
}

#===============================================================================
# lets get to work now...
#===============================================================================

$infile = $ARGV[0];
if(defined $ARGV[1]) {
  $outfile = $ARGV[1];
} else {
  $outfile = $infile;
  undef $outfile if $pref{'mode'} eq 'new';
}

open(FP, $infile) || die "error opening $infile $!";

my($buffer) = '';
my($dummy) = '';

#===============================================================================
# one time code for the 16bit dos "new" format
#===============================================================================

if($pref{'mode'} eq 'new') {

  #=============================================================================
  # figure out how big this file is
  #=============================================================================

  seek(FP, 0, 2) || die "cannot seek to end of $infile $!";
  $infile_size = tell FP;
  seek(FP, 0, 0) || die "cannot seek to beginning of $infile $!";

  #=============================================================================
  # use one time stamp for all fragments
  #=============================================================================

  $time_stamp = time;

  #=============================================================================
  # do some simple tests to reduce the file name in to something which
  # will work in 16bit DOS
  #=============================================================================

  $_ = $infile;
  s/\.tar\.gz$/.tgz/i;
  s/\.tar\.z$/.taz/i;
  s/\.jpeg$/.jpg/i;
  s/\..*\././g;
  $dos_fn = $_;
  ($outfile = $dos_fn) =~ s/\..*$//g unless defined $outfile; 
#  print "$dos_fn\n";

  #=============================================================================
  # stat the file for permission and ownership
  #=============================================================================

  ($infile_mode, $infile_uid, $infile_gid) = (stat $infile)[2,4,5];
}

while(!eof(FP)) {
  $fragment = &fragmentname;

  if($pref{'pause'}) {
    print "read for fragment $index\n";
    $dummy = <STDIN>;
  }

  die "error, file $fragment exists\n" 
      if((-e $fragment) and ($pref{'ow'} == 0));

  open(FRAG, ">$fragment") || die "error opening $outfile $!";

  $dest_offset = tell FP;
  read FP, $buffer, $pref{'size'};
  &header;
  print FRAG $buffer;
  close(FRAG);
}

#===============================================================================
# &header;  make and write a header for the 16bit DOS "new" fragment format
#===============================================================================

sub header {
  return 0 unless $pref{'mode'} eq 'new';

  my($header) = pack 'a3CCVVVCa12CCCV'  .	# 2.x
                     'vVVVV',			# 3.x

	#=======================================================================
        # original header stuf from new format for frag 2.x
	#=======================================================================

	'FRG',			# Id "FRG"
	2,			# version 0 = beta, 1 = frag 2.05, 2 = frag 3.00
	$index,			# index of the fragment (1,2,3,...)
	$time_stamp,		# time stamp (won't be correct for 16bit DOS)
	$dest_offset,		# where the fragment belongs in the file
	$infile_size,		# total size of the source
	length($dos_fn),	# length of the source file name
	$dos_fn,		# dos version of the file name
	56 + length($infile),	# size of the header (lo)
	0,			# size of the header (hi)
	0,			# frag mode (0=static, 1=dynamic size)
	$pref{'size'},		# expected size of each fragment

	#=======================================================================
        # new stuff for for unix version 3.x
	#=======================================================================

	$infile_mode,		# octal unix permission thing
	$infile_uid,		# user ID
	$infile_gid,		# group ID
	55,			# infile string location
	length($infile);	# length of the infile string

        $header .= "$infile\0";

#  print length($header), "\n";

  print FRAG $header;
}

#===============================================================================
# &fragmentname;
#===============================================================================

sub fragmentname {
  my($name);

  if($pref{'mode'} eq 'long') {
    $name = "$outfile.$index.frag";
    $index++;

  } elsif($pref{'mode'} eq 'new') {
    $index++;
    $name = "$outfile.f";
    $name .= '0' if($index < 10);
    $name .= $index;

  } else {
    $index++;
    $name = "$outfile$index.frg";
  }

  $name;
}

#===============================================================================
# &printhelp;
#===============================================================================

sub printhelp {
  print " GUTIL program frag by Graham THE Ollis.\n";
  print " version 3.00 (perl)\n";
  print "\n";
  print "  frag [options] source_file [destination file]\n";
  print "\n";
  print "frag (fragment file in to smaller files) makes using specified format.\n";
  print "\n";
  print "options available:\n";
  print "-S:s(t)       set size of the fragment size to s in terms of:\n";
  print "                s - segments (0xfffe = one segment)\n";
  print "                b - bytes, k - kilobytes, m - megabytes\n";
  print "-K:s          set size of the fragment to s in terms of bytes\n";
  print "-P            pause between each fragment\n";
  print "-old          use old format (no headers .frg files)\n";
  print "-new          use \"new\" 16bit dos format (with headers .fxx)\n";
  print "-long         use long file names no header format (.x.frag)\n";
}
